<?php
session_start();
if (empty($_SESSION['user_id'])) {
    header('Location: login.html');
    exit;
}
$username = htmlspecialchars($_SESSION['username']);
$avatar   = htmlspecialchars($_SESSION['avatar']);
$uid      = (int)$_SESSION['user_id'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>VideoEdit Tracker</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Space+Grotesk:wght@500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">
<link rel="stylesheet" href="css/style.css">
</head>
<body>

<!-- VIDEO BG -->
<div class="vbg">
  <video autoplay muted loop playsinline id="bg-video">
    <source src="https://assets.mixkit.co/videos/preview/mixkit-color-grading-with-a-control-panel-in-a-video-editing-studio-42954-large.mp4" type="video/mp4">
    <source src="https://assets.mixkit.co/videos/preview/mixkit-video-editing-on-a-laptop-computer-960-large.mp4" type="video/mp4">
  </video>
  <div class="vbg-overlay"></div>
</div>

<div class="sidebar">
  <div class="logo">
    <div class="logo-icon">🎬</div>
    VideoEdit
  </div>
  <nav>
    <a href="#" class="nav-item active" data-page="dashboard"><i class="ti ti-layout-dashboard"></i> Dashboard</a>
    <a href="#" class="nav-item" data-page="calendar"><i class="ti ti-calendar"></i> Calendar</a>
    <a href="#" class="nav-item" data-page="tasks"><i class="ti ti-checklist"></i> Daily Tasks</a>
    <a href="#" class="nav-item" data-page="focus"><i class="ti ti-clock"></i> Focus Timer</a>
    <a href="#" class="nav-item" data-page="progress"><i class="ti ti-chart-bar"></i> Progress</a>
  </nav>
  <div class="sidebar-bottom">
    <div class="user-pill">
      <div class="user-av"><?= $avatar ?></div>
      <div class="user-info">
        <div class="user-name"><?= $username ?></div>
        <div class="user-sub" id="sb-phase">Week 1</div>
      </div>
    </div>
    <div class="streak-pill">
      <span>🔥</span>
      <div>
        <div class="streak-num" id="sb-streak">0</div>
        <div class="streak-label">day streak</div>
      </div>
    </div>
    <div class="days-chip" id="sb-days">45 days left</div>
    <button class="logout-btn" onclick="logout()"><i class="ti ti-logout"></i> Logout</button>
  </div>
</div>

<div class="main">

  <!-- DASHBOARD -->
  <div class="page active" id="page-dashboard">
    <div class="page-header">
      <div>
        <div class="page-title" id="dash-greeting">Good morning! 👋</div>
        <div class="page-sub" id="dash-sub">Loading...</div>
      </div>
      <div class="date-badge" id="today-badge"></div>
    </div>
    <div class="stats-grid">
      <div class="stat-card"><div class="stat-icon">📅</div><div class="stat-label">Current Day</div><div class="stat-value" id="s-day">1</div><div class="stat-sub">of 45</div></div>
      <div class="stat-card"><div class="stat-icon">✅</div><div class="stat-label">Done Today</div><div class="stat-value" id="s-tasks">0</div><div class="stat-sub">tasks completed</div></div>
      <div class="stat-card"><div class="stat-icon">⏱️</div><div class="stat-label">Focus Time</div><div class="stat-value" id="s-focus">0m</div><div class="stat-sub">today</div></div>
      <div class="stat-card"><div class="stat-icon">🔥</div><div class="stat-label">Streak</div><div class="stat-value" id="s-streak">0</div><div class="stat-sub">days in a row</div></div>
    </div>
    <div class="progress-section">
      <div class="progress-header">
        <span class="progress-title">Overall Journey — Jun 13 to Jul 28</span>
        <span class="progress-pct" id="dash-pct">0%</span>
      </div>
      <div class="progress-track"><div class="progress-fill" id="dash-bar" style="width:0%"></div></div>
    </div>
    <div class="two-col">
      <div>
        <div class="sec-title">Today's Tasks</div>
        <div id="dash-tasks" class="task-list"></div>
      </div>
      <div>
        <div class="sec-title">Current Phase</div>
        <div class="phase-card" id="dash-phase"></div>
      </div>
    </div>
  </div>

  <!-- CALENDAR -->
  <div class="page" id="page-calendar">
    <div class="page-header">
      <div><div class="page-title">Calendar</div><div class="page-sub">Jun 13 – Jul 28, 2026</div></div>
      <div class="cal-nav">
        <button onclick="prevMonth()"><i class="ti ti-chevron-left"></i></button>
        <span id="cal-month-label"></span>
        <button onclick="nextMonth()"><i class="ti ti-chevron-right"></i></button>
      </div>
    </div>
    <div class="calendar-wrap">
      <div class="cal-grid" id="cal-grid"></div>
    </div>
    <div class="legend">
      <div class="leg"><div class="leg-dot" style="background:rgba(124,111,247,0.3);border:1.5px solid var(--accent)"></div> Today</div>
      <div class="leg"><div class="leg-dot" style="background:rgba(74,222,128,0.3)"></div> All done</div>
      <div class="leg"><div class="leg-dot" style="background:rgba(251,191,36,0.3)"></div> Partial</div>
      <div class="leg"><div class="leg-dot" style="background:var(--bg3)"></div> Planned</div>
    </div>
  </div>

  <!-- TASKS -->
  <div class="page" id="page-tasks">
    <div class="page-header">
      <div><div class="page-title">Daily Tasks</div><div class="page-sub">Check off tasks as you complete them</div></div>
      <div class="week-tabs" id="week-tabs"></div>
    </div>
    <!-- ADD CUSTOM TASK -->
    <div class="add-task-box">
      <div class="add-task-title"><i class="ti ti-plus"></i> Add Custom Task</div>
      <div class="add-task-row">
        <input type="text" id="custom-task-input" class="add-task-input" placeholder="e.g. Watch tutorial on color wheels..." maxlength="200">
        <input type="date" id="custom-task-date" class="add-task-date">
        <select id="custom-task-tag" class="add-task-tag">
          <option value="custom">custom</option>
          <option value="learn">learn</option>
          <option value="practice">practice</option>
          <option value="project">project</option>
        </select>
        <button class="add-task-btn" onclick="addCustomTask()"><i class="ti ti-plus"></i> Add</button>
      </div>
    </div>
    <div id="tasks-container"></div>
  </div>

  <!-- FOCUS TIMER -->
  <div class="page" id="page-focus">
    <div class="page-header">
      <div><div class="page-title">Focus Timer</div><div class="page-sub">Deep work sessions</div></div>
    </div>
    <div class="timer-wrap">
      <div class="timer-modes">
        <button class="mode-btn active" onclick="setMode('pomodoro',25,this)">🍅 Pomodoro 25m</button>
        <button class="mode-btn" onclick="setMode('short',5,this)">☕ Short 5m</button>
        <button class="mode-btn" onclick="setMode('long',15,this)">🛋️ Long 15m</button>
        <button class="mode-btn" onclick="setMode('custom',0,this)">⚙️ Custom</button>
      </div>
      <div class="timer-ring-wrap">
        <svg class="timer-svg" viewBox="0 0 220 220">
          <defs>
            <linearGradient id="ringGrad" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" style="stop-color:#7c6ff7"/>
              <stop offset="100%" style="stop-color:#a78bfa"/>
            </linearGradient>
          </defs>
          <circle cx="110" cy="110" r="95" class="ring-bg"/>
          <circle cx="110" cy="110" r="95" class="ring-fg" id="ring-fg"/>
        </svg>
        <div class="timer-inner">
          <div class="timer-time" id="timer-disp">25:00</div>
          <div class="timer-mode-lbl" id="timer-lbl">Pomodoro</div>
        </div>
      </div>
      <div class="custom-row" id="custom-row" style="display:none">
        <span>Minutes:</span>
        <input type="number" id="custom-min" min="1" max="180" value="30" class="custom-input">
        <button class="tbtn sec" onclick="applyCustom()">Set</button>
      </div>
      <div class="timer-btns">
        <button class="tbtn" onclick="startTimer()" id="btn-start"><i class="ti ti-player-play"></i> Start</button>
        <button class="tbtn sec" onclick="pauseTimer()" id="btn-pause" disabled><i class="ti ti-player-pause"></i> Pause</button>
        <button class="tbtn sec" onclick="resetTimer()"><i class="ti ti-refresh"></i> Reset</button>
      </div>
      <div class="task-link-row">
        <span>Linking to task:</span>
        <select id="timer-task-sel" class="task-sel"></select>
      </div>
      <div class="session-log">
        <div class="sec-title">Today's Sessions</div>
        <div id="session-list"></div>
      </div>
    </div>
  </div>

  <!-- PROGRESS -->
  <div class="page" id="page-progress">
    <div class="page-header">
      <div><div class="page-title">Progress</div><div class="page-sub">Your journey so far</div></div>
      <div style="display:flex;gap:10px">
        <div class="stat-chip">🔥 Best: <span id="prog-longest">0</span> days</div>
      </div>
    </div>
    <div class="graph-section">
      <div class="progress-header" style="margin-bottom:16px">
        <span class="progress-title">Daily Task Completion — Last 14 Days</span>
      </div>
      <div class="graph-bars" id="graph-bars"></div>
    </div>
    <div class="heatmap-wrap">
      <div class="progress-header" style="margin-bottom:14px">
        <span class="progress-title">Activity Heatmap</span>
        <span style="font-size:12px;color:var(--text3)">Jun 13 – Jul 28</span>
      </div>
      <div class="heatmap" id="heatmap"></div>
      <div class="hm-legend">
        <span style="font-size:11px;color:var(--text3)">Less</span>
        <div class="hm-cell"></div><div class="hm-cell level-1"></div>
        <div class="hm-cell level-2"></div><div class="hm-cell level-3"></div>
        <div class="hm-cell level-4"></div>
        <span style="font-size:11px;color:var(--text3)">More</span>
      </div>
    </div>
    <div class="sec-title">Weekly Breakdown</div>
    <div class="week-cards" id="week-cards"></div>
  </div>

</div>

<!-- TOAST -->
<div class="toast" id="toast">
  <span id="toast-icon">✅</span>
  <span id="toast-msg">Task completed!</span>
</div>

<!-- SOUNDS -->
<audio id="snd-complete" preload="auto">
  <source src="https://assets.mixkit.co/active_storage/sfx/2568/2568.wav" type="audio/wav">
</audio>
<audio id="snd-timer" preload="auto">
  <source src="https://assets.mixkit.co/active_storage/sfx/1362/1362.wav" type="audio/wav">
</audio>
<audio id="snd-click" preload="auto">
  <source src="https://assets.mixkit.co/active_storage/sfx/2571/2571.wav" type="audio/wav">
</audio>

<script src="js/data.js"></script>
<script src="js/app.js"></script>
<script>window.__USER__ = <?= json_encode(['id'=>$uid,'username'=>$username,'avatar'=>$avatar]) ?>;</script>
</body>
</html>
