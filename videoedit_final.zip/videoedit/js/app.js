// ═══════════════════════════════════════════════
//  VideoEdit Tracker — App Logic
// ═══════════════════════════════════════════════

const API = 'php/api.php';
const START = new Date('2026-06-13');
const END   = new Date('2026-07-28');
const TOTAL = 49; // total curriculum tasks

// ── STATE (synced from DB) ──────────────────────
let S = {
  done:     [],    // completed curriculum task IDs
  custom:   [],    // custom task objects
  sessions: [],    // focus sessions
  focus:    {},    // {date: mins}
  streak:   0,
  longest:  0,
  lastDate: null
};

// ── SOUNDS ─────────────────────────────────────
function playSound(id) {
  try {
    const a = document.getElementById(id);
    if (a) { a.currentTime = 0; a.volume = 0.4; a.play().catch(()=>{}); }
  } catch(e) {}
}

// ── TOAST ──────────────────────────────────────
let toastTimer;
function toast(msg, icon='✅', dur=2800) {
  const el  = document.getElementById('toast');
  const ic  = document.getElementById('toast-icon');
  const txt = document.getElementById('toast-msg');
  ic.textContent  = icon;
  txt.textContent = msg;
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), dur);
}

// ── API CALL ───────────────────────────────────
async function api(action, body = {}) {
  try {
    const res = await fetch(API, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action, ...body })
    });
    return await res.json();
  } catch (e) {
    console.error('API error:', e);
    return { ok: false, error: 'Network error' };
  }
}

// ── LOAD FROM DB ───────────────────────────────
async function loadAll() {
  const d = await api('get_all');
  if (!d.ok) return;
  S.done     = d.done || [];
  S.custom   = d.custom || [];
  S.sessions = d.sessions || [];
  S.focus    = d.focus || {};
  S.streak   = d.streak || 0;
  S.longest  = d.longest || 0;
  S.lastDate = d.lastDate || null;
  renderDashboard();
  updateSidebar();
}

// ── HELPERS ─────────────────────────────────────
function todayStr() { return new Date().toISOString().split('T')[0]; }
function dayNum() {
  const d = Math.floor((new Date(todayStr()) - START) / 86400000) + 1;
  return Math.max(1, Math.min(d, 45));
}
function daysLeft() { return Math.max(0, Math.floor((END - new Date(todayStr())) / 86400000)); }
function getPhase() {
  const w = Math.ceil(dayNum() / 7);
  return PHASES[Math.min(w - 1, PHASES.length - 1)];
}
function greeting() {
  const h = new Date().getHours();
  if (h < 12) return 'Good morning';
  if (h < 17) return 'Good afternoon';
  return 'Good evening';
}

// ── STREAK ─────────────────────────────────────
async function updateStreak() {
  const td = todayStr();
  if (S.lastDate === td) return;
  const yd = new Date(td); yd.setDate(yd.getDate() - 1);
  const yStr = yd.toISOString().split('T')[0];
  S.streak  = S.lastDate === yStr ? S.streak + 1 : 1;
  S.longest = Math.max(S.longest, S.streak);
  S.lastDate = td;
  await api('update_streak', { streak: S.streak, longest: S.longest, date: td });
  updateSidebar();
}

function updateSidebar() {
  document.getElementById('sb-streak').textContent = S.streak;
  document.getElementById('sb-days').textContent   = daysLeft() + ' days left';
  document.getElementById('sb-phase').textContent  = getPhase().label;
  const prog = document.getElementById('prog-longest');
  if (prog) prog.textContent = S.longest;
}

// ── TOGGLE CURRICULUM TASK ─────────────────────
async function toggleTask(id) {
  playSound('snd-click');
  const wasDone = S.done.includes(id);
  // Optimistic UI
  if (wasDone) S.done = S.done.filter(x => x !== id);
  else { S.done.push(id); await updateStreak(); }
  renderDashboard();
  if (document.getElementById('page-tasks').classList.contains('active')) renderTasks();

  const d = await api('toggle_task', { task_id: id });
  if (d.ok) {
    if (!wasDone) { playSound('snd-complete'); toast('Task completed! 🎉', '✅'); }
    else toast('Task unmarked', '↩️');
  }
}

// ── TOGGLE CUSTOM TASK ─────────────────────────
async function toggleCustom(id) {
  playSound('snd-click');
  const t = S.custom.find(x => x.id == id);
  if (!t) return;
  t.done = t.done ? 0 : 1;
  renderTasks();
  const d = await api('toggle_custom', { id });
  if (d.ok && t.done) { playSound('snd-complete'); toast('Custom task done! 🎉', '✅'); }
}

// ── DELETE CUSTOM TASK ─────────────────────────
async function deleteCustom(id) {
  if (!confirm('Delete this task?')) return;
  S.custom = S.custom.filter(x => x.id != id);
  renderTasks();
  await api('delete_custom', { id });
  toast('Task deleted', '🗑️');
}

// ── ADD CUSTOM TASK ────────────────────────────
async function addCustomTask() {
  const text = document.getElementById('custom-task-input').value.trim();
  const date = document.getElementById('custom-task-date').value || todayStr();
  const tag  = document.getElementById('custom-task-tag').value;
  if (!text) { toast('Please type a task first', '⚠️'); return; }

  const d = await api('add_custom', { text, date, tag });
  if (d.ok) {
    S.custom.push(d.task);
    document.getElementById('custom-task-input').value = '';
    renderTasks();
    playSound('snd-click');
    toast('Task added!', '➕');
  }
}

// ── DASHBOARD ──────────────────────────────────
function renderDashboard() {
  const td   = todayStr();
  const user = window.__USER__ || {};
  document.getElementById('dash-greeting').textContent = greeting() + ', ' + (user.avatar || '🎬') + ' ' + (user.username || '') + '!';
  document.getElementById('today-badge').textContent   = new Date().toLocaleDateString('en-US', { weekday:'long', month:'long', day:'numeric', year:'numeric' });
  document.getElementById('s-day').textContent         = dayNum();
  document.getElementById('s-streak').textContent      = S.streak;
  document.getElementById('sb-streak').textContent     = S.streak;

  const todayT    = TASKS.filter(t => t.day === td);
  const todayC    = S.custom.filter(t => t.task_date === td);
  const doneToday = todayT.filter(t => S.done.includes(t.id)).length + todayC.filter(t => t.done).length;
  document.getElementById('s-tasks').textContent = doneToday;

  const fm = S.focus[td] || 0;
  document.getElementById('s-focus').textContent = fm ? fm + 'm' : '0m';

  const pct = Math.round(S.done.length / TOTAL * 100);
  document.getElementById('dash-pct').textContent  = pct + '%';
  document.getElementById('dash-bar').style.width  = pct + '%';

  const ph = getPhase();
  document.getElementById('dash-sub').textContent  = ph.label + ' — ' + ph.title;

  // Today tasks
  const el = document.getElementById('dash-tasks');
  el.innerHTML = '';
  const allToday = [...todayT.map(t => ({...t, isCustom: false})), ...todayC.map(t => ({id: t.id, text: t.text, tag: t.tag || 'custom', done: !!t.done, isCustom: true}))];
  if (!allToday.length) {
    el.innerHTML = '<div class="empty"><i class="ti ti-calendar-off"></i>No tasks scheduled for today</div>';
  } else {
    allToday.forEach(t => {
      const done = t.isCustom ? !!t.done : S.done.includes(t.id);
      const d    = document.createElement('div');
      d.className = 'task-item' + (done ? ' done' : '');
      d.innerHTML = `<div class="task-check">${done ? '<i class="ti ti-check"></i>' : ''}</div><span class="task-text">${t.text}</span><span class="task-tag tag-${t.tag}">${t.tag}</span>`;
      d.onclick = () => t.isCustom ? toggleCustom(t.id) : toggleTask(t.id);
      el.appendChild(d);
    });
  }

  // Phase card
  document.getElementById('dash-phase').innerHTML = `
    <div class="phase-week">${ph.label}</div>
    <div class="phase-name">${ph.title}</div>
    <div class="phase-desc">${ph.desc}</div>
    ${ph.goals.map(g => `<div class="phase-goal"><i class="ti ti-arrow-right"></i>${g}</div>`).join('')}
  `;
}

// ── CALENDAR ───────────────────────────────────
let calY = new Date().getFullYear(), calM = new Date().getMonth();

function renderCalendar() {
  document.getElementById('cal-month-label').textContent = new Date(calY, calM).toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
  const grid = document.getElementById('cal-grid');
  grid.innerHTML = '';
  ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].forEach(d => {
    const h = document.createElement('div'); h.className = 'cal-head'; h.textContent = d; grid.appendChild(h);
  });
  const first = new Date(calY, calM, 1).getDay();
  const days  = new Date(calY, calM + 1, 0).getDate();
  const td    = todayStr();
  for (let i = 0; i < first; i++) { const e = document.createElement('div'); e.className = 'cal-cell out-range'; grid.appendChild(e); }
  for (let d = 1; d <= days; d++) {
    const ds  = `${calY}-${String(calM+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`;
    const inR = ds >= '2026-06-13' && ds <= '2026-07-28';
    const dt  = TASKS.filter(t => t.day === ds);
    const ct  = S.custom.filter(t => t.task_date === ds);
    const all = [...dt, ...ct];
    const doneCount = dt.filter(t => S.done.includes(t.id)).length + ct.filter(t => t.done).length;
    const allDone   = all.length > 0 && doneCount === all.length;
    const partial   = doneCount > 0 && !allDone;
    const isRest    = dt.length > 0 && dt.every(t => t.tag === 'rest') && ct.length === 0;
    const c = document.createElement('div');
    let cls = 'cal-cell';
    if (!inR) cls += ' out-range';
    else if (ds === td) cls += ' in-range is-today';
    else if (allDone) cls += ' in-range is-done';
    else if (partial) cls += ' in-range is-partial';
    else if (isRest) cls += ' in-range is-rest';
    else cls += ' in-range';
    c.className = cls;
    c.innerHTML = `<span class="cal-num">${d}</span>${inR && all.length && !allDone && !isRest ? `<span class="cal-dot" style="background:${doneCount > 0 ? 'var(--amber)' : 'var(--text3)'}"></span>` : ''}`;
    c.title = inR && all.length ? `${doneCount}/${all.length} tasks done` : '';
    grid.appendChild(c);
  }
}
function prevMonth() { calM--; if (calM < 0) { calM = 11; calY--; } renderCalendar(); }
function nextMonth() { calM++; if (calM > 11) { calM = 0; calY++; } renderCalendar(); }

// ── TASKS PAGE ─────────────────────────────────
let activeWeek = 1;

function renderTasks() {
  // Set today's date as default for custom task
  const dateInput = document.getElementById('custom-task-date');
  if (!dateInput.value) dateInput.value = todayStr();

  // Week tabs
  const tabs = document.getElementById('week-tabs');
  tabs.innerHTML = '';
  PHASES.forEach(ph => {
    const b = document.createElement('button');
    b.className = 'week-tab' + (ph.week === activeWeek ? ' active' : '');
    b.textContent = ph.label;
    b.onclick = () => { activeWeek = ph.week; renderTasks(); };
    tabs.appendChild(b);
  });

  const con = document.getElementById('tasks-container');
  con.innerHTML = '';
  const wt   = TASKS.filter(t => t.week === activeWeek);
  const days  = [...new Set(wt.map(t => t.day))];

  days.forEach(day => {
    const dt     = new Date(day + 'T12:00:00');
    const dn     = dt.toLocaleDateString('en-US', { weekday: 'long' });
    const dd     = dt.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    const dayT   = wt.filter(t => t.day === day);
    const customT = S.custom.filter(t => t.task_date === day);
    const allT   = dayT.length + customT.length;
    const doneC  = dayT.filter(t => S.done.includes(t.id)).length + customT.filter(t => t.done).length;
    const allDone = doneC === allT && allT > 0;
    const isToday = day === todayStr();

    const block = document.createElement('div');
    block.className = 'day-block';
    if (isToday) block.style.borderColor = 'rgba(124,111,247,0.35)';

    block.innerHTML = `
      <div class="day-header">
        <div class="day-header-left">
          <span class="day-date-label">${dd}${isToday ? ' <span style="color:var(--accent2);font-size:11px">• Today</span>' : ''}</span>
          <span class="day-name-label">${dn}</span>
        </div>
        ${allDone ? '<span class="day-done-badge"><i class="ti ti-check"></i> Complete</span>' : `<span class="day-count">${doneC}/${allT}</span>`}
      </div>
      <div class="day-tasks-body" id="dtb-${day}"></div>
    `;
    con.appendChild(block);

    const body = document.getElementById('dtb-' + day);
    [...dayT, ...customT.map(t => ({...t, isCustom: true}))].forEach(t => {
      const done    = t.isCustom ? !!t.done : S.done.includes(t.id);
      const el      = document.createElement('div');
      el.className  = 'task-item' + (done ? ' done' : '');
      el.innerHTML  = `
        <div class="task-check">${done ? '<i class="ti ti-check"></i>' : ''}</div>
        <span class="task-text">${t.text}</span>
        <span class="task-tag tag-${t.tag || 'custom'}">${t.tag || 'custom'}</span>
        ${t.isCustom ? `<button class="task-del" onclick="event.stopPropagation();deleteCustom(${t.id})" title="Delete"><i class="ti ti-trash"></i></button>` : ''}
      `;
      el.onclick = () => t.isCustom ? toggleCustom(t.id) : toggleTask(t.id);
      body.appendChild(el);
    });
  });
}

// ── FOCUS TIMER ────────────────────────────────
let timerTotal = 25 * 60, timerLeft = timerTotal, timerRunning = false, timerIv = null;
const CIRC = 2 * Math.PI * 95;

function setMode(mode, mins, btn) {
  document.querySelectorAll('.mode-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  document.getElementById('custom-row').style.display = mode === 'custom' ? 'flex' : 'none';
  document.getElementById('timer-lbl').textContent = btn.textContent.replace(/^[\S]+\s/,'').split(' ')[0];
  if (mode !== 'custom') { timerTotal = mins * 60; timerLeft = timerTotal; resetTimer(); }
}
function applyCustom() {
  const m = +document.getElementById('custom-min').value || 30;
  timerTotal = m * 60; timerLeft = timerTotal; resetTimer();
}
function updateTimerDisp() {
  const m = Math.floor(timerLeft / 60), s = timerLeft % 60;
  document.getElementById('timer-disp').textContent = `${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
  const offset = CIRC * (1 - timerLeft / timerTotal);
  document.getElementById('ring-fg').style.strokeDashoffset = offset;
}
function startTimer() {
  if (timerRunning) return;
  timerRunning = true;
  document.getElementById('btn-start').disabled = true;
  document.getElementById('btn-pause').disabled = false;
  timerIv = setInterval(() => {
    timerLeft--;
    updateTimerDisp();
    if (timerLeft <= 0) {
      clearInterval(timerIv); timerRunning = false;
      logSession();
      document.getElementById('btn-start').disabled = false;
      document.getElementById('btn-pause').disabled = true;
      playSound('snd-timer');
      toast('Focus session complete! Great work 💪', '⏱️', 4000);
    }
  }, 1000);
}
function pauseTimer() {
  clearInterval(timerIv); timerRunning = false;
  document.getElementById('btn-start').disabled = false;
  document.getElementById('btn-pause').disabled = true;
}
function resetTimer() {
  clearInterval(timerIv); timerRunning = false; timerLeft = timerTotal;
  updateTimerDisp();
  document.getElementById('btn-start').disabled = false;
  document.getElementById('btn-pause').disabled = true;
}
async function logSession() {
  const td   = todayStr();
  const mins = Math.round(timerTotal / 60);
  const sel  = document.getElementById('timer-task-sel');
  const task = sel.options[sel.selectedIndex]?.text || 'General focus';
  const time = new Date().toLocaleTimeString([], { hour:'2-digit', minute:'2-digit' });
  S.sessions.unshift({ task_name: task, mins, session_date: td, session_time: time });
  S.focus[td] = (S.focus[td] || 0) + mins;
  renderSessions();
  renderDashboard();
  await api('log_session', { task, mins, date: td, time });
}
function renderSessions() {
  const td   = todayStr();
  const list = document.getElementById('session-list');
  list.innerHTML = '';
  const ts = S.sessions.filter(s => s.session_date === td);
  if (!ts.length) { list.innerHTML = '<div class="empty"><i class="ti ti-moon"></i>No sessions yet</div>'; return; }
  ts.forEach(s => {
    const e = document.createElement('div'); e.className = 'session-item';
    e.innerHTML = `<span>${s.task_name}</span><span class="session-dur">${s.mins}m · ${s.session_time}</span>`;
    list.appendChild(e);
  });
}
function renderFocusPage() {
  const sel = document.getElementById('timer-task-sel');
  sel.innerHTML = '<option>General focus</option>';
  const td = todayStr();
  [...TASKS.filter(t => t.day === td), ...S.custom.filter(t => t.task_date === td)].forEach(t => {
    const o = document.createElement('option');
    o.textContent = t.text.substring(0, 48) + (t.text.length > 48 ? '...' : '');
    sel.appendChild(o);
  });
  updateTimerDisp(); renderSessions();
}

// ── PROGRESS PAGE ──────────────────────────────
function renderProgress() {
  document.getElementById('prog-longest').textContent = S.longest;

  // 14-day bar graph
  const bars = document.getElementById('graph-bars');
  bars.innerHTML = '';
  const td = todayStr();
  for (let i = 13; i >= 0; i--) {
    const d  = new Date(td); d.setDate(d.getDate() - i);
    const ds = d.toISOString().split('T')[0];
    const dt = TASKS.filter(t => t.day === ds);
    const ct = S.custom.filter(t => t.task_date === ds);
    const all = dt.length + ct.length;
    const doneCount = dt.filter(t => S.done.includes(t.id)).length + ct.filter(t => t.done).length;
    const pct = all ? doneCount / all : 0;
    const h   = Math.max(4, Math.round(pct * 120));
    const isT = ds === td;
    const lbl = d.toLocaleDateString('en-US', { month:'numeric', day:'numeric' });
    const w   = document.createElement('div'); w.className = 'gbar-wrap';
    w.innerHTML = `<div class="gbar${pct > 0 ? ' has-data' : ''}${isT ? ' today-bar' : ''}" style="height:${h}px" title="${ds}: ${Math.round(pct*100)}%"></div><span class="gbar-label">${lbl}</span>`;
    bars.appendChild(w);
  }

  // Heatmap
  const hm = document.getElementById('heatmap');
  hm.innerHTML = '';
  const s = new Date('2026-06-13'), e = new Date('2026-07-28');
  for (let d = new Date(s); d <= e; d.setDate(d.getDate() + 1)) {
    const ds = d.toISOString().split('T')[0];
    const dt = TASKS.filter(t => t.day === ds);
    const ct = S.custom.filter(t => t.task_date === ds);
    const all = dt.length + ct.length;
    const done = dt.filter(t => S.done.includes(t.id)).length + ct.filter(t => t.done).length;
    const pct  = all ? done / all : 0;
    const lvl  = pct === 0 ? 0 : pct < 0.34 ? 1 : pct < 0.67 ? 2 : pct < 1 ? 3 : 4;
    const c = document.createElement('div');
    c.className = `hm-cell level-${lvl}${ds === td ? ' today-cell' : ''}`;
    c.title = `${ds}: ${Math.round(pct*100)}%`;
    hm.appendChild(c);
  }

  // Week cards
  const wc = document.getElementById('week-cards');
  wc.innerHTML = '';
  PHASES.forEach(ph => {
    const wt   = TASKS.filter(t => t.week === ph.week);
    const done = wt.filter(t => S.done.includes(t.id)).length;
    const pct  = wt.length ? Math.round(done / wt.length * 100) : 0;
    const card = document.createElement('div'); card.className = 'week-card';
    card.innerHTML = `
      <div class="wc-header">
        <div><div class="wc-week">${ph.label}</div><div class="wc-title">${ph.title}</div></div>
        <div class="wc-pct">${pct}%</div>
      </div>
      <div class="wc-track"><div class="wc-fill" style="width:${pct}%"></div></div>
      <div class="wc-meta">${done}/${wt.length} tasks · ${ph.goals[0]}</div>
    `;
    wc.appendChild(card);
  });
}

// ── NAVIGATION ─────────────────────────────────
document.querySelectorAll('.nav-item').forEach(item => {
  item.addEventListener('click', e => {
    e.preventDefault();
    playSound('snd-click');
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
    item.classList.add('active');
    const pg = item.dataset.page;
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    document.getElementById('page-' + pg).classList.add('active');
    if (pg === 'calendar') renderCalendar();
    if (pg === 'tasks')    renderTasks();
    if (pg === 'focus')    renderFocusPage();
    if (pg === 'progress') renderProgress();
  });
});

// ── LOGOUT ─────────────────────────────────────
async function logout() {
  await fetch('php/auth.php', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({action:'logout'}) });
  window.location.href = 'login.html';
}

// ── ENTER KEY for custom task ───────────────────
document.addEventListener('DOMContentLoaded', () => {
  const inp = document.getElementById('custom-task-input');
  if (inp) inp.addEventListener('keydown', e => { if (e.key === 'Enter') addCustomTask(); });
});

// ── INIT ───────────────────────────────────────
calY = new Date().getFullYear(); calM = new Date().getMonth();
loadAll();
