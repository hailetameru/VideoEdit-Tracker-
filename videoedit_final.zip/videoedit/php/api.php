<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }

require_once 'config.php';
$uid    = authRequired();
$conn   = getDB();
$input  = json_decode(file_get_contents('php://input'), true) ?? [];
$action = $_GET['action'] ?? $input['action'] ?? '';

switch ($action) {

// ── GET ALL STATE ─────────────────────────────────────────
case 'get_all':
    $done     = array_column($conn->query("SELECT task_id FROM completed_tasks WHERE user_id=$uid")->fetch_all(MYSQLI_ASSOC), 'task_id');
    $custom   = $conn->query("SELECT * FROM custom_tasks WHERE user_id=$uid ORDER BY task_date, id")->fetch_all(MYSQLI_ASSOC);
    $sessions = $conn->query("SELECT * FROM sessions WHERE user_id=$uid ORDER BY created_at DESC LIMIT 200")->fetch_all(MYSQLI_ASSOC);
    $streak   = $conn->query("SELECT * FROM streak WHERE user_id=$uid")->fetch_assoc();
    $focus    = $conn->query("SELECT focus_date, total_mins FROM focus_time WHERE user_id=$uid")->fetch_all(MYSQLI_ASSOC);
    $focusMap = [];
    foreach ($focus as $f) $focusMap[$f['focus_date']] = (int)$f['total_mins'];
    jsonOut([
        'ok'       => true,
        'done'     => array_map('intval', $done),
        'custom'   => $custom,
        'sessions' => $sessions,
        'streak'   => (int)($streak['current_streak'] ?? 0),
        'longest'  => (int)($streak['longest_streak'] ?? 0),
        'lastDate' => $streak['last_date'] ?? null,
        'focus'    => $focusMap
    ]);
    break;

// ── TOGGLE CURRICULUM TASK ────────────────────────────────
case 'toggle_task':
    $id = (int)($input['task_id'] ?? 0);
    if (!$id) jsonOut(['ok'=>false,'error'=>'Missing task_id']);
    $exists = $conn->query("SELECT id FROM completed_tasks WHERE user_id=$uid AND task_id=$id")->num_rows > 0;
    if ($exists) {
        $conn->query("DELETE FROM completed_tasks WHERE user_id=$uid AND task_id=$id");
        jsonOut(['ok'=>true,'status'=>'removed']);
    } else {
        $conn->query("INSERT INTO completed_tasks (user_id, task_id) VALUES ($uid, $id)");
        jsonOut(['ok'=>true,'status'=>'added']);
    }
    break;

// ── ADD CUSTOM TASK ───────────────────────────────────────
case 'add_custom':
    $text = $conn->real_escape_string(trim($input['text'] ?? ''));
    $date = $conn->real_escape_string($input['date'] ?? date('Y-m-d'));
    $tag  = $conn->real_escape_string($input['tag'] ?? 'custom');
    if (!$text) jsonOut(['ok'=>false,'error'=>'Task text required']);
    $conn->query("INSERT INTO custom_tasks (user_id, task_date, text, tag) VALUES ($uid, '$date', '$text', '$tag')");
    $newId = $conn->insert_id;
    jsonOut(['ok'=>true,'task'=>['id'=>$newId,'user_id'=>$uid,'task_date'=>$date,'text'=>$text,'tag'=>$tag,'done'=>0]]);
    break;

// ── TOGGLE CUSTOM TASK ────────────────────────────────────
case 'toggle_custom':
    $id = (int)($input['id'] ?? 0);
    $row = $conn->query("SELECT done FROM custom_tasks WHERE id=$id AND user_id=$uid")->fetch_assoc();
    if (!$row) jsonOut(['ok'=>false,'error'=>'Not found']);
    $newDone = $row['done'] ? 0 : 1;
    $conn->query("UPDATE custom_tasks SET done=$newDone WHERE id=$id AND user_id=$uid");
    jsonOut(['ok'=>true,'done'=>$newDone]);
    break;

// ── DELETE CUSTOM TASK ────────────────────────────────────
case 'delete_custom':
    $id = (int)($input['id'] ?? 0);
    $conn->query("DELETE FROM custom_tasks WHERE id=$id AND user_id=$uid");
    jsonOut(['ok'=>true]);
    break;

// ── LOG FOCUS SESSION ─────────────────────────────────────
case 'log_session':
    $task = $conn->real_escape_string($input['task'] ?? 'General focus');
    $mins = (int)($input['mins'] ?? 0);
    $date = $conn->real_escape_string($input['date'] ?? date('Y-m-d'));
    $time = $conn->real_escape_string($input['time'] ?? date('H:i'));
    $conn->query("INSERT INTO sessions (user_id, task_name, mins, session_date, session_time) VALUES ($uid, '$task', $mins, '$date', '$time')");
    $conn->query("INSERT INTO focus_time (user_id, focus_date, total_mins) VALUES ($uid, '$date', $mins)
                  ON DUPLICATE KEY UPDATE total_mins = total_mins + $mins");
    jsonOut(['ok'=>true]);
    break;

// ── UPDATE STREAK ─────────────────────────────────────────
case 'update_streak':
    $streak  = (int)($input['streak'] ?? 0);
    $date    = $conn->real_escape_string($input['date'] ?? date('Y-m-d'));
    $longest = (int)($input['longest'] ?? $streak);
    $conn->query("INSERT INTO streak (user_id, current_streak, longest_streak, last_date) VALUES ($uid, $streak, $longest, '$date')
                  ON DUPLICATE KEY UPDATE current_streak=$streak, last_date='$date',
                  longest_streak=GREATEST(longest_streak, $streak)");
    jsonOut(['ok'=>true]);
    break;

// ── PROGRESS DATA ─────────────────────────────────────────
case 'progress':
    $daily = $conn->query("
        SELECT session_date as date, SUM(mins) as mins, COUNT(*) as sessions
        FROM sessions WHERE user_id=$uid
        AND session_date >= DATE_SUB(CURDATE(), INTERVAL 45 DAY)
        GROUP BY session_date ORDER BY session_date
    ")->fetch_all(MYSQLI_ASSOC);
    $taskDates = $conn->query("
        SELECT DATE(completed_at) as date, COUNT(*) as count
        FROM completed_tasks WHERE user_id=$uid
        GROUP BY DATE(completed_at) ORDER BY date
    ")->fetch_all(MYSQLI_ASSOC);
    jsonOut(['ok'=>true,'daily'=>$daily,'taskDates'=>$taskDates]);
    break;

default:
    jsonOut(['ok'=>false,'error'=>'Unknown action: '.$action]);
}
$conn->close();
