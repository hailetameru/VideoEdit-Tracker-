<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'videoedit');

function getDB() {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    if ($conn->connect_error) {
        http_response_code(500);
        echo json_encode(['ok' => false, 'error' => 'DB error: ' . $conn->connect_error]);
        exit;
    }
    $conn->set_charset('utf8mb4');
    return $conn;
}

function jsonOut($data) {
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

function authRequired() {
    session_start();
    if (empty($_SESSION['user_id'])) {
        jsonOut(['ok' => false, 'error' => 'Not authenticated', 'redirect' => 'login.php']);
    }
    return $_SESSION['user_id'];
}
