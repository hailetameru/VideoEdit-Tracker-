<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }

require_once 'config.php';
session_start();

$input  = json_decode(file_get_contents('php://input'), true) ?? [];
$action = $input['action'] ?? '';

$conn = getDB();

// ── REGISTER ──────────────────────────────────────────────
if ($action === 'register') {
    $username = trim($input['username'] ?? '');
    $email    = trim($input['email'] ?? '');
    $password = $input['password'] ?? '';
    $avatar   = $input['avatar'] ?? '🎬';

    if (!$username || !$email || !$password)
        jsonOut(['ok' => false, 'error' => 'All fields required']);

    if (strlen($username) < 3)
        jsonOut(['ok' => false, 'error' => 'Username must be at least 3 characters']);

    if (!filter_var($email, FILTER_VALIDATE_EMAIL))
        jsonOut(['ok' => false, 'error' => 'Invalid email address']);

    if (strlen($password) < 6)
        jsonOut(['ok' => false, 'error' => 'Password must be at least 6 characters']);

    $stmt = $conn->prepare("SELECT id FROM users WHERE username=? OR email=?");
    $stmt->bind_param('ss', $username, $email);
    $stmt->execute();
    if ($stmt->get_result()->num_rows > 0)
        jsonOut(['ok' => false, 'error' => 'Username or email already exists']);

    $hash = password_hash($password, PASSWORD_BCRYPT);
    $stmt = $conn->prepare("INSERT INTO users (username, email, password, avatar) VALUES (?,?,?,?)");
    $stmt->bind_param('ssss', $username, $email, $hash, $avatar);
    $stmt->execute();
    $uid = $conn->insert_id;

    // Create streak row
    $conn->query("INSERT INTO streak (user_id, current_streak) VALUES ($uid, 0)");

    $_SESSION['user_id']  = $uid;
    $_SESSION['username'] = $username;
    $_SESSION['avatar']   = $avatar;

    jsonOut(['ok' => true, 'user' => ['id' => $uid, 'username' => $username, 'avatar' => $avatar]]);
}

// ── LOGIN ─────────────────────────────────────────────────
if ($action === 'login') {
    $login    = trim($input['login'] ?? '');
    $password = $input['password'] ?? '';

    if (!$login || !$password)
        jsonOut(['ok' => false, 'error' => 'Email/username and password required']);

    $stmt = $conn->prepare("SELECT id, username, password, avatar FROM users WHERE email=? OR username=?");
    $stmt->bind_param('ss', $login, $login);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();

    if (!$user || !password_verify($password, $user['password']))
        jsonOut(['ok' => false, 'error' => 'Invalid credentials']);

    $_SESSION['user_id']  = $user['id'];
    $_SESSION['username'] = $user['username'];
    $_SESSION['avatar']   = $user['avatar'];

    jsonOut(['ok' => true, 'user' => ['id' => $user['id'], 'username' => $user['username'], 'avatar' => $user['avatar']]]);
}

// ── LOGOUT ────────────────────────────────────────────────
if ($action === 'logout') {
    session_destroy();
    jsonOut(['ok' => true]);
}

// ── CHECK SESSION ─────────────────────────────────────────
if ($action === 'check') {
    if (!empty($_SESSION['user_id'])) {
        jsonOut(['ok' => true, 'user' => [
            'id'       => $_SESSION['user_id'],
            'username' => $_SESSION['username'],
            'avatar'   => $_SESSION['avatar']
        ]]);
    } else {
        jsonOut(['ok' => false]);
    }
}

jsonOut(['ok' => false, 'error' => 'Unknown action']);
