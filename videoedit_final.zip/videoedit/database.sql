-- VideoEdit Tracker Database
-- Run this in phpMyAdmin > SQL tab

CREATE DATABASE IF NOT EXISTS videoedit CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE videoedit;

-- USERS
CREATE TABLE IF NOT EXISTS users (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    username     VARCHAR(50) UNIQUE NOT NULL,
    email        VARCHAR(100) UNIQUE NOT NULL,
    password     VARCHAR(255) NOT NULL,
    avatar       VARCHAR(10) DEFAULT '🎬',
    created_at   DATETIME DEFAULT NOW()
);

-- COMPLETED TASKS (curriculum)
CREATE TABLE IF NOT EXISTS completed_tasks (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    user_id      INT NOT NULL,
    task_id      INT NOT NULL,
    completed_at DATETIME DEFAULT NOW(),
    UNIQUE KEY user_task (user_id, task_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- CUSTOM TASKS (user-added)
CREATE TABLE IF NOT EXISTS custom_tasks (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    user_id      INT NOT NULL,
    task_date    DATE NOT NULL,
    text         VARCHAR(500) NOT NULL,
    tag          VARCHAR(20) DEFAULT 'custom',
    done         TINYINT(1) DEFAULT 0,
    created_at   DATETIME DEFAULT NOW(),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- FOCUS SESSIONS
CREATE TABLE IF NOT EXISTS sessions (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    user_id      INT NOT NULL,
    task_name    VARCHAR(255),
    mins         INT DEFAULT 0,
    session_date DATE,
    session_time VARCHAR(10),
    created_at   DATETIME DEFAULT NOW(),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- STREAK
CREATE TABLE IF NOT EXISTS streak (
    id             INT AUTO_INCREMENT PRIMARY KEY,
    user_id        INT UNIQUE NOT NULL,
    current_streak INT DEFAULT 0,
    longest_streak INT DEFAULT 0,
    last_date      DATE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- FOCUS TIME PER DAY
CREATE TABLE IF NOT EXISTS focus_time (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    user_id     INT NOT NULL,
    focus_date  DATE NOT NULL,
    total_mins  INT DEFAULT 0,
    UNIQUE KEY user_date (user_id, focus_date),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
